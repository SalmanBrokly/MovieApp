package com.example.movieapp

object Constants {
    //    https://api.themoviedb.org/3/discover/movie?api_key=b72ed8f0eb8ceb93ff64cfb965521024
    /*api base url*/
    val BASE_URL = "https://api.themoviedb.org/3/"

    val MOVIE_API_KEY="b72ed8f0eb8ceb93ff64cfb965521024"
}