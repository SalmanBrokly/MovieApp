package com.example.movieapp.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer

import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager

import com.example.movieapp.R
import com.example.movieapp.repository.ViewModelProvider
import com.example.movieapp.utils
import com.example.movieapp.viewmodel.MovieViewModel
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(){

    private lateinit var mViewModel: MovieViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMovieList.layoutManager = LinearLayoutManager(this)
        val mAdpater = MovieAdapter(this)
        rvMovieList.adapter = mAdpater
        mViewModel = ViewModelProviders.of(this, ViewModelProvider(this@MainActivity.application))
            .get(MovieViewModel::class.java)

        mViewModel.movieData!!.observe(this@MainActivity, Observer { movieData ->
progressBar1.visibility= View.INVISIBLE
            if (movieData.size != 0) {
                mAdpater.submitList(movieData)
                Log.e("tag", movieData.size.toString())
            } else {
                Toast.makeText(this, "no data found", Toast.LENGTH_SHORT).show()
            }
        })

        progressBar1.visibility= View.VISIBLE
        if (utils.isNetworkAvailable(this)) {
            mViewModel.getMovieLiveData()
        } else {
            mViewModel.getList()
        }
    }


}
