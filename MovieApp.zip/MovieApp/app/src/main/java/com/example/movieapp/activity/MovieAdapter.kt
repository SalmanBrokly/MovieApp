package com.example.movieapp.activity

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import com.example.movieapp.pojo.Result

import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.movieapp.R
import kotlinx.android.synthetic.main.row_movielist.view.*

class MovieAdapter(val context: Context) : ListAdapter<Result, MovieAdapter.ViewHolder>(DiffCallback()) {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.row_movielist, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
//        holder.setValues(getItem(position))

    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: Result) = with(itemView) {
            // TODO: Bind the data with View
            itemView.tvMovieTitile.text = item.original_title
            itemView.tvMovieId.text = item.id.toString()
            itemView.tvMoviePopolarity.text = item.popularity.toString()
            setOnClickListener {
                // TODO: Handle on click

                val intent = Intent(context, MovieDetailsActivity::class.java)
                intent.putExtra("data","")
                context.startActivity(intent)
            }
        }


        fun setValues(item: Result) {
            itemView.tvMovieTitile.text = item.original_title
        }
    }

}

class DiffCallback : DiffUtil.ItemCallback<Result>() {
    override fun areItemsTheSame(oldItem: Result, newItem: Result): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Result, newItem: Result): Boolean {
        return oldItem == newItem
    }
}
