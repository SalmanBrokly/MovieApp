package com.example.movieapp.apiservices

import com.example.movieapp.pojo.MovieData
import com.google.gson.JsonElement
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiInterfaces {

    @GET("discover/movie?")
    fun getMovieList(@Query("api_key") api_Key:String):Call<MovieData>

}