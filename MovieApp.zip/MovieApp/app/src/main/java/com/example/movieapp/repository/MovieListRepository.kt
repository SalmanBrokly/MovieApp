package com.example.movieapp.repository

import android.content.Context
import android.os.AsyncTask
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.Room
import com.example.movieapp.Constants
import com.example.movieapp.apiservices.ApiClient
import com.example.movieapp.apiservices.ApiInterfaces
import com.example.movieapp.pojo.MovieData
import com.example.movieapp.pojo.Result
import com.example.movieapp.roomdata.AppDatabase
import com.example.movieapp.utils
import com.google.gson.JsonElement
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MovieListRepository() {
    private lateinit var appDatabase: AppDatabase


    fun getMovieListApiCalling( liveData: MutableLiveData<List<Result>>,context: Context) {
//        appDatabase = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()

            val apiClient = ApiClient.instance.value
            apiClient.apiServices!!.getMovieList(Constants.MOVIE_API_KEY).enqueue(object : Callback<MovieData> {
                override fun onResponse(call: Call<MovieData>, response: Response<MovieData>) {
                    liveData.value = response.body()!!.results
                  val data =  AppDatabase.getInstance(context)
                    doAsync {
                        //Execute all the lon running tasks here
                        data.movieDao().insertAll(response.body()?.results!!)
                    }
                }
                override fun onFailure(call: Call<MovieData>, t: Throwable) {

                }
            })
    }


}