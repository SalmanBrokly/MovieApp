package com.example.movieapp.repository

import android.app.Application
import android.content.Context
import androidx.annotation.NonNull
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.movieapp.viewmodel.MovieViewModel

class ViewModelProvider(application: Application): ViewModelProvider.NewInstanceFactory() {

    private val mApplication: Context?
    private val mParam: String? = null


    init  {
        mApplication = application
    }
    @SuppressWarnings("unchecked")
    @NonNull
    @Override
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MovieViewModel(this.mApplication!!) as T
    }
}
