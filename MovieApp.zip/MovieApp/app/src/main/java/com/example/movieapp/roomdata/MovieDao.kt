package com.example.movieapp.roomdata

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.movieapp.pojo.Result

/**
 * The Data Access Object for the Movie class.
 */
@Dao
interface MovieDao {
    @Query("SELECT * FROM Movie")
    fun getMovies(): List<Result>

 /*   @Query("SELECT * FROM plants WHERE growZoneNumber = :growZoneNumber ORDER BY name")
    fun getPlantsWithGrowZoneNumber(growZoneNumber: Int): LiveData<List<Plant>>

    @Query("SELECT * FROM plants WHERE id = :plantId")
    fun getPlant(plantId: String): LiveData<Plant>*/

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(movie: List<Result>)
}