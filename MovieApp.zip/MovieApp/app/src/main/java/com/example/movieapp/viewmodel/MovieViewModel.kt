package com.example.movieapp.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.movieapp.pojo.MovieData
import com.example.movieapp.pojo.Result
import com.example.movieapp.repository.MovieListRepository
import com.example.movieapp.roomdata.AppDatabase
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class MovieViewModel(val context: Context) : ViewModel(){
    var mContext:Context?
    internal var movieData : MutableLiveData<List<Result>>? = null
    val  movie : MovieListRepository = MovieListRepository()
    init {
        this.mContext=context
        movieData = MutableLiveData<List<Result>>()
    }



    fun getMovieLiveData(){
        movieData?.let { movie.getMovieListApiCalling(it,context) }
    }

    fun getList(){
        doAsync {
            movieData?.postValue(    AppDatabase.getInstance(context).movieDao().getMovies())
               uiThread {
                        //Update the UI thread here
                Log.e("tastdons","done");

                    }
        }
    }

}